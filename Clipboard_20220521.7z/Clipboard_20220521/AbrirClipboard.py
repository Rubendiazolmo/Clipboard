import pyperclip
import keyboard
import time

# Leer registro de clipboard
buffer = open('clipboard.txt','r', encoding='utf-8')
elementos = buffer.read().split("\n ---------------------------------------------------")
buffer.close()

# Mostrar el registro de clipboard. Si el texto es muy largo se muetran solo los 180 primeros caracteres.
for i, elemento in enumerate(elementos):
    if len(elemento) > 180:
        elemento = elemento[0:177] + "..."
    print(f'{i}: {elemento}')
    print("---------------------------")

indice = int((input("Seleccione el elemento a copiar: ")))

pyperclip.copy(elementos[indice].replace("salto_de_linea", "\r"))

keyboard.press_and_release('alt + tab')
time.sleep(0.15)
keyboard.press_and_release('ctrl + v')
