import pyperclip
from base64 import b64decode
import os
import sys

# Leer registro de clipboard
buffer = open('clipboard.txt','r', encoding='utf-8')
elementos = buffer.readlines()
buffer.close()

# Inicializo respusta que va mostrar el script
respuesta = "El portapapeles está vacio, copie para empezar a rellenarlo.\nPresione ENTER para terminar..."

# Decodificar el archivo clipboard.txt
for i in range(len(elementos)):
    elementos[i] = (b64decode(elementos[i]).decode('utf-8'))

# Mostrar el registro de clipboard. Si el texto es muy largo se muetran solo los 180 primeros caracteres.
for i, elemento in enumerate(elementos):
    if elemento != "":
        # Si hay algo copiado en la clipboard cambio el texto a mostrar en el script.
        respuesta = "Seleccione el elemento a copiar: "
        if len(elemento) > 180:
            elemento = elemento[0:177] + "..."
        print(f'{i}: {elemento}')
        print("---------------------------")
 
indice = (input(respuesta))

# Salir del script si no se selecciona ningún elemento a copiar.
if indice == "":
    sys.exit()

indice = int(indice)

pyperclip.copy(elementos[indice])

os.system("AltTabMasCopiar.vbs")
